'use strict';
// PreToolUse guard: parses each shell command (quotes, operators, wrappers, nested shells) and denies
// permanently forbidden operations. Complements the static deny rules, which only match text.
const path = require('path');

const GIT_WRITE = new Set(['add', 'commit', 'push', 'merge', 'rebase', 'cherry-pick', 'checkout', 'switch', 'reset', 'stash', 'tag',
  'clean', 'rm', 'apply', 'restore', 'revert', 'am', 'pull', 'fetch', 'mv', 'worktree', 'update-ref', 'gc', 'prune', 'replace', 'notes']);
const GIT_OPTION_WITH_VALUE = new Set(['-C', '-c', '--git-dir', '--work-tree', '--namespace', '--exec-path', '--super-prefix', '--config-env']);
const GIT_BRANCH_WRITE = new Set(['-d', '-D', '-m', '-M', '-c', '-C', '-f', '-u', '--delete', '--move', '--copy', '--force',
  '--set-upstream-to', '--unset-upstream', '--edit-description']);
const GIT_BRANCH_READ = new Set(['--show-current', '--list', '-l', '-a', '-r', '-v', '-vv', '--all', '--remotes', '--verbose', '--contains',
  '--no-contains', '--merged', '--no-merged', '--sort', '--format']);
const GIT_CONFIG_WRITE = new Set(['--global', '--system', '--unset', '--unset-all', '--add', '--replace-all', '--edit', '-e',
  '--rename-section', '--remove-section']);
const GIT_REMOTE_WRITE = new Set(['add', 'set-url', 'remove', 'rm', 'rename', 'set-head', 'set-branches', 'prune', 'update']);
const GH_ACTION_WRITE = new Set(['create', 'edit', 'close', 'merge', 'comment', 'review', 'reopen', 'delete', 'ready', 'transfer', 'rename',
  'archive', 'unarchive', 'fork', 'sync', 'rerun', 'cancel', 'lock', 'unlock', 'pin', 'unpin', 'checkout', 'develop', 'clone', 'upload']);
const GH_GROUP_DENY = new Set(['api', 'release', 'secret', 'variable', 'workflow', 'gist', 'auth', 'ssh-key', 'gpg-key', 'codespace',
  'extension', 'alias', 'project', 'label', 'ruleset', 'cache', 'config', 'attestation']);
const PACKAGE_PUBLISH = new Set(['publish', 'deploy']);
const LAUNCH = new Set(['start-process', 'invoke-item', 'ii', 'invoke-expression', 'iex', 'explorer', 'xdg-open', 'wine', 'start',
  'renderdoc', 'qrenderdoc', 'x64dbg', 'x32dbg', 'ghidrarun', 'ida', 'ida64', 'invoke-webrequest', 'invoke-restmethod', 'iwr', 'irm']);
const REMOTE_TOOLS = new Set(['wrangler', 'twine']);
const LAUNCH_SCRIPT = /^(run|launch|start|play|worker)\.(ps1|sh)$/i;
const LAUNCH_FLAG = /^-{1,2}(run|launch)$/i;
const WRAPPERS = new Set(['env', 'command', 'exec', 'builtin', 'nice', 'nohup', 'time', 'timeout', 'stdbuf', 'sudo', 'setsid', 'xargs', 'rtk',
  'proxy', 'call', '&', '.', 'source']);
const SHELL_INTERPRETERS = new Set(['bash', 'sh', 'zsh', 'dash', 'ksh']);
const PWSH_INTERPRETERS = new Set(['pwsh', 'powershell']);

function splitSegments(text) {
  const segments = [];
  let tokens = [];
  let word = '';
  let quote = null;
  let started = false;
  const pushWord = () => { if (started) tokens.push(word); word = ''; started = false; };
  const pushSegment = () => { pushWord(); if (tokens.length) segments.push(tokens); tokens = []; };
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (quote) {
      if (ch === quote) quote = null;
      else if (ch === '\\' && quote === '"' && text[i + 1] === '"') word += text[++i];
      else word += ch;
      continue;
    }
    if (ch === '"' || ch === "'") { quote = ch; started = true; continue; }
    if (ch === '`' && i + 1 < text.length) { word += text[++i]; started = true; continue; }
    if (/\s/.test(ch) && ch !== '\n') { pushWord(); continue; }
    if (ch === '\n' || ch === ';' || ch === '|' || ch === '(' || ch === ')' || ch === '{' || ch === '}') { pushSegment(); continue; }
    if (ch === '&') {
      if (text[i + 1] === '&') { pushSegment(); i++; continue; }
      if (!started && !tokens.length) { tokens.push('&'); continue; }
      pushSegment();
      continue;
    }
    word += ch;
    started = true;
  }
  pushSegment();
  return segments;
}

function exeName(token) {
  return path.basename(token.replace(/\\/g, '/')).toLowerCase().replace(/\.(exe|cmd|bat)$/, '');
}

function stripWrappers(tokens) {
  let t = tokens.slice();
  for (let guard = 0; guard < 20 && t.length; guard++) {
    if (/^[A-Za-z_][A-Za-z0-9_]*=/.test(t[0]) || /^\$env:[^=]+=/.test(t[0])) { t.shift(); continue; }
    const name = exeName(t[0]);
    if (!WRAPPERS.has(name)) break;
    t.shift();
    if (name === 'env') while (t.length && (t[0].startsWith('-') || /^[A-Za-z_][A-Za-z0-9_]*=/.test(t[0]))) t.shift();
    else if (name === 'timeout') { while (t.length && t[0].startsWith('-')) t.shift(); if (t.length) t.shift(); }
    else if (name === 'nice') { if (t[0] === '-n') t.splice(0, 2); else if (t[0] && /^-\d+$/.test(t[0])) t.shift(); }
    else if (name === 'sudo') while (t.length && t[0].startsWith('-')) t.shift();
  }
  return t;
}

function gitVerdict(args) {
  let i = 0;
  while (i < args.length && args[i].startsWith('-')) {
    const opt = args[i].split('=')[0];
    i += GIT_OPTION_WITH_VALUE.has(opt) && !args[i].includes('=') ? 2 : 1;
  }
  const sub = args[i];
  if (!sub) return null;
  const rest = args.slice(i + 1);
  if (GIT_WRITE.has(sub)) return `git ${sub}`;
  if (['diff', 'log', 'show', 'format-patch'].includes(sub) && rest.some(a => a === '-o' || a.startsWith('--output'))) return `git ${sub} --output`;
  if (sub === 'submodule' && rest.some(a => !a.startsWith('-') && a !== 'status' && a !== 'summary' && a !== 'foreach')) return 'git submodule (write)';
  if (sub === 'submodule' && rest.includes('foreach')) return 'git submodule foreach';
  if (sub === 'branch') {
    const flags = rest.filter(a => a.startsWith('-'));
    const names = rest.filter(a => !a.startsWith('-'));
    if (flags.some(f => GIT_BRANCH_WRITE.has(f))) return 'git branch (write)';
    if (names.length && !flags.some(f => GIT_BRANCH_READ.has(f.split('=')[0]))) return 'git branch <name>';
  }
  if (sub === 'config') {
    if (rest.some(a => GIT_CONFIG_WRITE.has(a))) return 'git config (write)';
    const positional = rest.filter(a => !a.startsWith('-'));
    const reading = rest.some(a => /^(--get|--get-all|--get-regexp|--list|-l|--show-origin|--show-scope)/.test(a));
    if (positional.length >= 2 && !reading) return 'git config (write)';
  }
  if (sub === 'remote' && rest.some(a => GIT_REMOTE_WRITE.has(a))) return 'git remote (write)';
  if (sub === 'reflog' && rest.some(a => ['expire', 'delete'].includes(a))) return 'git reflog (write)';
  if (sub === 'grep' && rest.some(a => a === '-O' || a.startsWith('--open-files-in-pager'))) return 'git grep -O';
  return null;
}

function ghVerdict(args) {
  const words = args.filter(a => !a.startsWith('-'));
  if (!words.length) return null;
  if (GH_GROUP_DENY.has(words[0])) return `gh ${words[0]}`;
  if (words[1] && GH_ACTION_WRITE.has(words[1])) return `gh ${words[0]} ${words[1]}`;
  return null;
}

function decodeEncoded(token) {
  try { return Buffer.from(token, 'base64').toString('utf16le'); } catch { return ''; }
}

function evaluate(text, depth) {
  if (depth > 3) return null;
  for (const raw of splitSegments(text)) {
    const tokens = stripWrappers(raw);
    if (!tokens.length) continue;
    const name = exeName(tokens[0]);
    const args = tokens.slice(1);
    let hit = null;
    if (name === 'git') hit = gitVerdict(args);
    else if (name === 'gh') hit = ghVerdict(args);
    else if (REMOTE_TOOLS.has(name)) hit = name;
    else if (LAUNCH.has(name)) hit = name;
    else if (['npm', 'pnpm', 'yarn', 'cargo', 'bun'].includes(name)) {
      const words = args.filter(a => !a.startsWith('-'));
      if (PACKAGE_PUBLISH.has(words[0]) || (words[0] === 'run' && words[1] === 'deploy')) hit = `${name} ${words[0]}`;
      else if (words.some(w => exeName(w) === 'wrangler') || (['exec', 'dlx', 'x'].includes(words[0]) && words.some(w => exeName(w) === 'wrangler'))) hit = 'wrangler';
      else if (name === 'cargo' && words[0] === 'run') hit = 'cargo run';
      else if (name === 'npm' && words[0] === 'start') hit = 'npm start';
    }
    else if (['npx', 'bunx'].includes(name) && args.some(a => exeName(a) === 'wrangler')) hit = 'wrangler';
    else if (['docker', 'podman'].includes(name) && args.includes('push')) hit = `${name} push`;
    else if (name === 'terraform' && args.includes('apply')) hit = 'terraform apply';
    else if (name === 'kubectl' && args.includes('apply')) hit = 'kubectl apply';
    else if (name === 'dotnet' && args[0] === 'run') hit = 'dotnet run';
    else if (name === 'go' && args[0] === 'run') hit = 'go run';
    else if (name === 'curl' && args.some(a => /^(-X|--request)$/i.test(a)) && args.some(a => /^(POST|PUT|PATCH|DELETE)$/i.test(a))) hit = 'curl write';
    else if (name === 'curl' && args.some(a => /^(-d|-F|-T|--data.*|--form|--upload-file)$/.test(a))) hit = 'curl upload';
    else if (name === 'cmd' && /^\/c$/i.test(args[0] || '') && args[1]) { hit = evaluate(args.slice(1).join(' '), depth + 1); }
    else if (SHELL_INTERPRETERS.has(name)) {
      const k = args.findIndex(a => /^-[a-z]*c$/.test(a));
      if (k >= 0 && args[k + 1]) hit = evaluate(args[k + 1], depth + 1);
      else if (args[0] && !args[0].startsWith('-') && LAUNCH_SCRIPT.test(path.basename(args[0].replace(/\\/g, '/')))) hit = args[0];
    }
    else if (PWSH_INTERPRETERS.has(name)) {
      for (let k = 0; k < args.length && !hit; k++) {
        if (/^-(c|command)$/i.test(args[k]) && args[k + 1]) hit = evaluate(args.slice(k + 1).join(' '), depth + 1);
        else if (/^-(e|ec|encodedcommand)$/i.test(args[k]) && args[k + 1]) hit = evaluate(decodeEncoded(args[k + 1]), depth + 1);
        else if (LAUNCH_SCRIPT.test(path.basename(args[k].replace(/\\/g, '/')))) hit = args[k];
      }
    }
    if (!hit && LAUNCH_SCRIPT.test(path.basename(tokens[0].replace(/\\/g, '/')))) hit = tokens[0];
    if (!hit && tokens.some(t => /\.(ps1|sh)$/i.test(t)) && tokens.some(t => LAUNCH_FLAG.test(t))) hit = 'script -Run/-Launch';
    if (hit) return hit;
  }
  return null;
}

let input = '';
process.stdin.on('data', chunk => { input += chunk; });
process.stdin.on('end', () => {
  let command = '';
  try { command = (JSON.parse(input).tool_input || {}).command || ''; } catch { return; }
  let hit = null;
  try { hit = evaluate(command, 0); } catch { return; }
  if (!hit) return;
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: {
      hookEventName: 'PreToolUse',
      permissionDecision: 'deny',
      permissionDecisionReason: `Blocked by the project command guard: ${hit}. Git writes, publishing, deploys and launches are permanently forbidden; prepare the command as text for the user.`,
    },
  }));
});
