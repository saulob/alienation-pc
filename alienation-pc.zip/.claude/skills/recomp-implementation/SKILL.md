---
name: recomp-implementation
description: Use to implement a bounded feature or fix in a game recompilation or port when the cause or design is already known - small edits, reuse of existing patterns, settings and persistence, rollback on failure, per-build differences, Windows and Linux. Implement first, validate lightly, hand over for manual testing.
---

# Controlled implementation

## Steps

1. Restate the change in one or two lines and list the files it touches. If it needs more than a handful of files, or the cause is not proven, use `recomp-investigation` first.
2. Find the nearest existing example of the same kind of change in this repository (a hook, a patch, a setting, a UI entry, a localization entry) and copy its pattern. Do not add abstractions, frameworks or helper layers for one use.
3. Make the edit, keeping the repository's line endings and style. Use the editing tools, not a text-mode script that rewrites line endings.
4. Think through the failure paths before finishing:
   - Settings: default, missing key, invalid value, restart-required versus live. Update the project's docs only when player-visible behaviour changed.
   - Persistence and save data: never change a save format or save bytes without an explicit requirement; old data must stay readable.
   - Binary patches and hooks: locate by fingerprint, verify bytes before writing, restore on failure, never overlap another patch, keep instruction sizes correct.
   - Game builds: if a change is build-specific, gate it by build and state which builds were not covered.
   - Windows and Linux: find where the project splits platform code and state what is unverified on the other platform.
5. Update `test.ps1` when the change is automatically verifiable (new patch, fingerprint, build, setting, hotkey, language, save field, platform or packaging option, fixed regression): a small fast static or headless check next to the existing ones, no duplicate, no artificial test. If it depends on GPU, UI, audio or gameplay, give a manual test instead. A change to a Cloudflare Worker keeps `worker.ps1` working; never run it.
6. Validate lightly with the `lightweight-validation` skill. Do not build.
7. Hand over: files changed, tests added and not automatable, limitations, and the exact manual test (what to do, expected result, what to send back on failure). The test must need no environment variables, commands, hand-edited config or repeated rebuilds; prefer a temporary `DEBUG_SAULO` hotkey over anything else when a toggle is needed.

## Rules

- Change only what the task needs. No cleanups of unrelated code, no rewritten comments.
- Comments: none by default, one short line for a real non-obvious constraint. Temporary diagnostics are `DEBUG_SAULO`.
- No Git writes, no builds, no game or launcher launches.
