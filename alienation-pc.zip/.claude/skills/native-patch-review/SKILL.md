---
name: native-patch-review
description: Use to review native hooks, binary patches, fingerprints, ABI-sensitive code and memory handling in a diff of a game recompilation or port. Returns findings by severity with evidence. Read-only; use before declaring a risky change ready for testing.
---

# Native patch review

Review the diff (`git diff`, `git status`) and the code it touches. Report; do not edit. Learn the guest and host architectures and calling conventions from the repository first.

## Checklist

- **Fingerprints.** Is the site found by byte pattern with enough context to be unique, and verified before writing? Does it match on every supported game build, or refuse cleanly where it differs? Is an address used alone where a fingerprint is needed?
- **Overlap and size.** Do two patches or hooks touch the same bytes or share an instruction that straddles a boundary? Is the overwritten length at least the stub size and never split an instruction? Are the original bytes kept for rollback?
- **ABI and calling convention.** Check argument registers or stack, stack alignment, preserved registers, red zone, vector state, and every transition between the original code's convention and the host's (the two can differ).
- **Register use.** Does a trampoline clobber a register the original code still needs? Is flag state preserved where later code depends on it?
- **Ownership and lifetime.** Who allocates and frees; can a pointer outlive its object; are guest pointers validated before the host dereferences them?
- **Concurrency.** Guest threads, fibers, interrupts and the render or audio threads: unlocked shared state, non-atomic read-modify-write, a hook on an unexpected thread, patch installation racing a running guest thread.
- **Atomicity and rollback.** Is a patch written in one step or can another thread observe half of it? After a partial failure is everything restored or left consistent? Does the rollback path actually run?
- **Errors.** Every failed lookup, allocation or protection change is handled and logged without crashing the guest.
- **Memory corruption.** Bounds on copies into guest memory, integer overflow in sizes and offsets, writes through stale pointers, writes to read-only or executable pages without restoring protection.
- **Persistence and save data.** Anything written to a save or user file that other versions or builds read.
- **Build compatibility.** A locator per supported build; on an unknown build the behaviour is a clear refusal, not a guess.
- **Hygiene.** Verbose, historical or tutorial comments; stray `DEBUG_SAULO`; wrong line endings; unrelated edits.

Use this checklist for the native part of the `final-reviewer` pass too; the final pass adds cleanup, Windows/Linux parity, `test.ps1`, build log and release checks.

## Output

Findings ordered critical, high, medium, low. Each: `path:line`, what is wrong, the concrete failing scenario, the evidence (bytes, call path, register). Then the areas checked with no finding, and what cannot be verified without running the game, stated as a manual test for the user.
