---
name: cross-platform-parity
description: Use when a feature or fix touches behaviour that exists on one host platform (for example Windows) and should exist on another (for example Linux or a handheld), or the reverse - to compare real code paths, find differences in APIs, paths, input, GPU, audio, config and packaging, and list pending items without inventing support.
---

# Cross-platform parity

Applies only when the project supports more than one host platform. Confirm which ones from the repository (build files, docs, CI, packaging) before comparing.

## Method

1. List the code paths of the feature. For each, find the platform split with Grep: preprocessor guards, platform-specific source files (`*_win*`, `*_posix*`, `*_linux*` and similar), platform branches in build files, and PowerShell versus shell versions of the same script.
2. Compare, with evidence, the differences that matter:
   - APIs and runtime: memory model, threads and fibers, time, file access, signal or exception handling.
   - Paths and filesystem: separators, case sensitivity, portable data folders, links, read-only package mounts.
   - Input: gamepad and keyboard backends, hotkeys, layouts.
   - GPU and renderer: which backends exist on which platform, driver and present-mode differences.
   - Audio, window management and DPI (100%, 150% and 225% for UI work).
   - Configuration and persistence: keys honoured on both, save and settings locations.
   - Launcher, updater, bug reporting and other tooling.
   - Packaging: archive versus bundle format, bundled libraries, minimum system library versions.
   - Features enabled on one platform and disabled on the other, on purpose or not.
3. Classify each item: same code and behaviour (evidence: shared file and no guard), different code with equivalent behaviour (evidence needed), different behaviour, missing on one side, not verifiable here.
4. For each gap give the file, what is missing, and whether it is a bug, a deliberate limit (cite the doc) or unknown.

## Rules

- Do not declare parity without evidence. Shared code is evidence of shared logic, not of the same runtime result.
- Do not invent support, drivers or behaviour that the code and docs do not show.
- Tests that need a window or the game are manual; list them as pending for the user.
- Headless checks in a Linux environment (for example WSL) are allowed when the project already uses them; they must not start the game or a display session.
- Parity is functional, never just a clean compile: launcher, UI, menus, settings, hotkeys, controls, cheats, saves, achievements, audio, video, rendering, resolutions, FPS, multiplayer, online, localization, logs, bug reports, persistence, error handling, startup and shutdown, runtime, plugins, packaging. A platform the project does not support is not applicable.
- In a final review also compare the packaged artifacts (ZIP versus AppImage): same features, resources and licences, differences listed with evidence.
- Output: a short table of feature, state per platform, evidence, pending item.
