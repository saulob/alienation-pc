---
name: release-audit
description: Use to prepare or review a release of a game recompilation or port using the project's own flows - Windows and Linux artifact checks (contents, licences, README, version, names, SHA-256, glibc, RPATH, bundled libraries) - without building or packaging unless the user explicitly asks; never tagging, committing, publishing or uploading, even on request.
---

# Release audit

Local only. Never publish, tag, commit, upload or edit a remote, even if the user asks; the user does it manually. Never change the version unless asked. Never run packaging or builds unless the user explicitly asks; otherwise audit what already exists. Find the project's official release flow in its scripts, docs and CI before auditing; do not assume artifact names or folders. Release candidates get the `final-reviewer` pass; builds and packaging go to `build-release` only when the user asks. A Cloudflare Worker is deployed by the user with `worker.ps1`; check it still matches `wrangler` config, never run it.

## Version and names

- Find where the version is written (build file, header or manifest) and check that README, docs, changelog and the artifact names agree with it.
- Check artifact names against the project's own naming scheme and that every artifact has its checksum file.

## Windows artifacts

- Use the project's packaging script as the reference for what must be inside. Check: release configuration with debug information stripped or separated, the runtime and renderer plugin files, only the DLLs the executable imports, configuration defaults, licence texts, README.
- Must not ship: game data, user saves, logs, caches, original game executables or archives, `DEBUG_SAULO` strings, absolute local paths, build leftovers.
- The SHA-256 of each archive matches its checksum file (`Get-FileHash` or `sha256sum`).

## Linux artifacts

- Audit with read-only tools (`readelf`, `objdump`, `ldd`, `strings`, `sha256sum`): architecture, bundle layout, highest glibc symbol version against the documented baseline, RPATH and RUNPATH pointing inside the bundle, bundled libraries are the intended ones and system libraries (GPU drivers, loader, display server, libc) are not bundled, the documented fallback when FUSE is unavailable, licence texts, checksum file.
- Do not run the artifact as a game. Do not start a display.

## AppImage (official format versus AppImageHub)

Sources: docs.appimage.org (reference/appdir, packaging-guide, packaging-guide/distribution), appimage.github.io, github.com/AppImage/appimage.github.io. Consult them when a rule is in doubt; do not invent requirements. Keep the format requirements apart from the extra AppImageHub catalog criteria. Do not open catalog PRs or publish.

- AppDir: executable `AppRun` (or symlink to the main binary), `.desktop` entry at the root with valid `Exec` and `Icon`, icon at the root and in the icon theme, AppStream metadata in `usr/share/metainfo` when the project ships it, relative paths only, RPATH/RUNPATH inside the bundle, licences of bundled libraries. Validate with `desktop-file-validate` and `appstreamcli validate` when installed.
- Target x86_64 when that is the project's target. glibc: highest `GLIBC_` symbol of every bundled ELF against the project's baseline (keep Ubuntu 20.04 / glibc 2.31 where the project sets it); never raise it silently. Do not bundle libc, the GPU driver stack or the display server libraries.
- Runtime: the project's approved upstream AppImage runtime with pinned tag, commit and hashes; no unverified downloaded binaries. The `--appimage-extract-and-run` fallback must keep working without FUSE. Config, saves and logs go outside the read-only mount; a relaunch uses the original AppImage path (`$APPIMAGE`).
- Name: follow the project's pattern (default `ProjectName-v<version>-x86_64.AppImage`), not wrapped in ZIP or tar.gz, and without a stray platform word when the convention omits it.
- With ReXGlue-style runtimes: check the stamp or fingerprint, reject a stale or stock runtime, check the GPU plugin and staging, and package the Release build.

## Release hygiene (both platforms)

- Absent from every package: game data and proprietary game files, platform executables and packages (for example `default.xex`, `.pkg`), saves and `user_data`, logs including the numbered build logs, temporary files, memory and crash dumps, `DEBUG_SAULO`, local settings, credentials, tokens and API keys, personal directories and developer absolute paths (search ASCII and UTF-16 strings), unintended debug symbols, RenderDoc, diagnostic Vulkan layers, test files, unexpected dependencies, old release files, stale binaries. Keep required components and mandatory licences. Recompute hashes after any change.
- Windows and Linux artifacts must carry the same feature set and resources; list differences with evidence.

## VirusTotal

- Target zero detections, never promised. Never upload a file to VirusTotal or any external service, even if the user asks; the user uploads manually. Without a real report the status is NOT VERIFIED.
- With a report: list detections and engines, investigate real causes (packers, unsigned installers, downloads, unusual API use), fix real problems, mark probable false positives, point to the vendors' legitimate false-positive process. No obfuscators, packers or evasion.
- Prefer trusted pinned dependencies, SHA-256 integrity, correct version metadata, transparent startup, no unexpected downloads or remote execution, and a digital signature when available.

## Report

Per item: evidence checked, pass or fail, and the exact command the user must run for anything not verified. List files that must not ship and any tracked file that should not be committed.
