---
name: recomp-investigation
description: Use to investigate a crash, startup failure, wrong behaviour or build difference in a game recompilation or port from logs, executables, imports, RVAs, hooks and fingerprints. Produces probable cause plus evidence and the smallest next step. Do not use for implementing a known fix.
---

# Recomp investigation

Evidence first. A fix without evidence is not an answer. Learn the platform and runtime from the repository (and `.claude/project-context.md` when present) before assuming anything about executable formats or conventions.

## Flow

1. **Symptom.** What fails, when (install, boot, menu, gameplay, shutdown), on which game build and host platform. Ask the user for the log when none is given.
2. **Evidence.** Collect before reading code:
   - Build failures: the newest numbered build log (`<project>_NNN.log` in the build log folder), first error first; do not rebuild to get more output.
   - Logs: the project's log folders and the last session only; the first error and the last line before a crash, not the whole file.
   - Executable and module identity: original format (for example XEX, ELF/SELF, NES ROM, other), hashes, which game build it is, and how the project detects builds.
   - Imports and stubs: unresolved or stubbed system calls and their runtime implementations; any import inventory or name table the project keeps.
   - Crash data: call stacks, fault address and module, registers, generated or translated code addresses.
3. **Region of code.** Locate the hook, patch, translated function or runtime function with Grep on the symbol, RVA, address or log string. Read only that region and its callers.
4. **Hypotheses.** Two or three, each with what would confirm or kill it.
5. **Static verification.** Prove or kill each one without running the game:
   - Disassemble the relevant bytes from the original executable or image with the tools the project or host provides (`objdump`, a disassembler, or a reverse-engineering MCP if available).
   - Compare the same site across game builds; a fingerprint must match exact bytes, not only an address.
   - Check the calling convention at the site: argument registers or stack, alignment, preserved registers, what a hook clobbers.
   - Use a headless diagnostic only if the project documents one, a built binary already exists and the user allows it.
6. **Result.** Most probable cause with evidence (`path:line`, addresses, log lines), confidence, and what is still unproven.
7. **Next minimal step.** One action: a diagnostic to add, a log the user should send, a single targeted change. Mark temporary diagnostics `DEBUG_SAULO`.

## Rules

- Never launch the game, a launcher or any window. The user runs gameplay tests.
- No builds. No random edits to "see what happens".
- Differences between game builds, regions or platforms are the first suspect when one works and another fails.
- Report unknowns as unknowns. Do not guess addresses or offsets.
- Hard cases with no cause after one pass: hand the evidence to `native-specialist` instead of repeating the search.
