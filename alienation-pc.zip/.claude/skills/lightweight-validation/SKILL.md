---
name: lightweight-validation
description: Use after an edit to validate it cheaply without building - diff inspection, whitespace and line-ending checks, syntax checks, fingerprint and overlapping-patch checks, quick already-compiled headless tests - and to list the build and manual test commands for the user instead of running them.
---

# Lightweight validation

No build, no GUI, no long suites, no Git writes.

## Checks, in order of cost

1. `git status --short` and `git diff --stat`: only the intended files changed, nothing new untracked that should be ignored.
2. `git diff --check`: whitespace errors.
3. Line endings of every touched file match the repository's. Count carriage returns with a binary-safe tool (`tr -cd '\r' < file | wc -c`); do not rely on `grep -c $'\r'` through the shell tool, which can match every line.
4. Read the whole diff once. Look for unrelated edits, comments that are history or tutorials, leftover `DEBUG_SAULO`, mixed tabs and spaces, wrong include or declaration order.
5. Syntax of touched files without building the project:
   - JSON: parse it with `node` or `python -I`.
   - PowerShell: `[System.Management.Automation.Language.Parser]::ParseFile(...)` and read the errors.
   - Shell: `bash -n file.sh`.
   - Python: `python -I -m py_compile file.py`.
   - C, C++ and other compiled code: a syntax-only compile of a single file only when its flags and include paths are known and it needs no dependency fetch; otherwise read carefully and say it was not compiled. Be suspicious of edits made with escape sequences through the shell tool (backslashes can be collapsed).
6. Fingerprints and patches: for changed locators or patch tables, confirm byte patterns and lengths against fixture data already on disk, and check that no two patches overlap.
7. Existing warnings: read warnings from a previous build log already on disk; do not trigger a build to get them.
8. Quick tests: run an already compiled test executable only when it exists, is known to open no window, play no audio and touch no production network. Never run the project's full test gate unless the user asked.

9. New automatable behaviour: confirm `test.ps1` (or the project's gate) gained a fast static or headless check for it and that no existing check was dropped; list what cannot be automated. `build.ps1` must stay incremental and each run must produce one new numbered log; the last log on disk is the place to read warnings.
10. A Cloudflare Worker script (`worker.ps1`): parse it, check it locates files through `$PSScriptRoot`, restores the working directory and stores no token. Never run it.

## Hand-over

The manual test must need no preparation by the user: no environment variables, console commands, hand-edited INI or JSON, launch scripts or repeated rebuilds. Normal build, normal launch, test, send the log. If a runtime toggle is unavoidable, use a temporary hotkey or an existing diagnostic menu (check key conflicts), marked `DEBUG_SAULO` and removed before release.

List, without running them: the build command the user should run (taken from the project's scripts or docs), the test gate if relevant, and the manual in-game test with the expected result. End with what was verified and what was not.
