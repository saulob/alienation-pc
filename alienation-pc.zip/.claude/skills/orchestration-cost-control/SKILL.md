---
name: orchestration-cost-control
description: Use when deciding whether to delegate to a subagent, which agent and model to use, how many agents to run, how to brief them, and how to report agents and token cost honestly. Keeps delegation minimal; do not use it to justify delegating.
---

# Orchestration and cost control

## Decide: direct or delegate

Do it directly when the work is a handful of tool calls, a lookup of a known file, one small edit, or when you already hold the needed context. Delegate only for a concrete benefit:

- Isolation: the investigation reads many files or large logs and only the conclusion matters (scout).
- Specialization: hard native analysis (native-specialist) or an independent read of a risky diff (reviewer).
- A defined multi-file plan to execute (implementer), once the plan exists.

Zero subagents is the default. One when isolation or specialization pays. Two only for really independent work. Sequential unless there is an explicit reason to parallelize. No chains of delegation, no recursion, no second implementer on the same files, no same investigation on two models.

## Choose the model

Cheapest model that finishes correctly.

| Need | Claude Code | OpenCode |
|---|---|---|
| search, inventory, small logs | scout: haiku 5.5 low | scout: deepseek-v4.1-flash |
| bounded investigation, larger logs, evidence for another agent | scout: haiku 5.5 medium | scout: deepseek-v4.1-flash |
| defined implementation, known-cause fix, launcher/settings/hotkeys, focused tests, simple review | implementer: sonnet 5.5 medium | implementer: deepseek-v4-pro |
| diff review | reviewer: sonnet 5.5 medium (high for a deep technical review) | reviewer: deepseek-v4-pro |
| reverse engineering, unknown crash, hard ABI/hooks, memory, concurrency, architecture | native-specialist: opus 5.5 medium (high only for exceptionally hard, after solid investigation) | native-specialist: kimi-k3.1-pro |
| build errors, packaging, AppImage, release hygiene (only when the user asked for a build or release) | build-release: sonnet 5.5 medium (high for complex Release prep or investigation) | build-release: deepseek-v4-pro |
| final review: branch closure, release, critical review | final-reviewer: opus 5.5 medium (high with a technical reason) | final-reviewer: kimi-k3.1-pro |
| exceptional: very large architectural refactor, complex migration, problem Opus high could not solve | Fable 5.2, only if available and justified | n/a |

`reviewer` stays the quick review; `final-reviewer` is read-only and never used for trivial diffs, never repeated after a small change. Neither `build-release` nor `final-reviewer` runs on simple tasks. Never hand ABI, hard concurrency, architecture or hard hooks to Haiku.

## Effort and escalation

- Sonnet medium is the starting point for any clearly specified task. High needs a reason (complex or extensive risky change, deep review, delicate platform compatibility); C, C++, Vulkan or recompilation alone is not one.
- Unknown cause that really needs deep reasoning: Opus medium directly, not a series of Sonnet high attempts. Opus high only after solid investigation still leaves hard hypotheses open. Fable only exceptionally.
- Raise effort before raising model, but it is not a mandatory ladder. Before escalating, name the cause of the failure: missing context, insufficient evidence, wrong spec, implementation error, tool limit, or real reasoning complexity. Fix that first.
- Never repeat the same prompt on another model without new evidence; never switch model just because the first attempt failed.

High, xhigh or max effort needs a technical reason. Opus never for searching, simple commands or log summaries. Claude subscription and OpenCode plan are separate; never assume shared credits. If a model is unavailable use the tool's configured fallback; do not name ids that `opencode models` does not list.

## Brief and consume

- A subagent sees nothing of this chat. Give: goal, exact files or paths, what is already ruled out, the constraint set (no Git writes, no builds, no launches), and the short answer format (paths, lines, addresses, evidence).
- Minimize context: ranges instead of whole files, Grep before Read, ask for conclusions and evidence, not dumps.
- Do not redo what a subagent already returned. If its result is thin, narrow the question; do not repeat it elsewhere.
- Consolidate: merge results into one conclusion with the evidence that matters.
- Do not reread files or repeat closed investigations; do not load every skill upfront; keep `project-context.md` for when it matters.
- Ask subagents for short answers with evidence and paths, not long reports. Delegation cost counts in total: do not delegate to make the orchestrator look cheaper.
- Validate proportionally: minimal static check, then manual test; do not repeat a validation that passed and was not affected. Memory, ABI, hooks, patches and concurrency get extra validation matching the risk; never trade native safety for tokens.
- Suggest compaction or a new session when a long session would benefit, keeping evidence of ongoing investigations.

## Report honestly

- List agents actually run (main included), model, effort when known, task, result. State "0 subagents" when none.
- Tokens and cost only from data the tool exposes (for example the session usage display). Otherwise write `N/D - not available`. Never estimate per-agent cost without data; show an aggregate as an aggregate.
- API-equivalent cost is not a bill. On a subscription do not present it as extra spending. Do not add figures from different plans together.
- Do not create scripts, resident processes or extra model calls to measure cost, and do not add an agent whose only job is accounting.
