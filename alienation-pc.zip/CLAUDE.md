# Game recompilation project (universal local AI rules)

Local file, ignored by Git (`/CLAUDE.md`). Read by Claude Code, and by OpenCode through `.opencode/opencode.json` (`instructions`) plus `AGENTS.md`.
This file is identical in every recompilation or port project: it names no game, platform or path. Facts about the current repository come from discovery (section 1) and the optional `.claude/project-context.md`.
Reply to the user in the language they write in. Keep code, commits and docs in English.

## 1. Project discovery (do it from evidence, only as much as the task needs)

Do not assume the platform, runtime, language or structure. Do not run a full discovery on a small task and do not repeat it once known in the session. First read `.claude/project-context.md` if it exists and is relevant; it is optional and its absence changes nothing. Then confirm only what the task needs from the repository itself: `README`, the build files (`CMakeLists.txt`, `Makefile`, solution or project files, `build.*` scripts), `tools/`, `scripts/`, `tests/`, `docs/`, `.github/`, and the source.

Identify when relevant:

- project name and original game platform (for example PS4, Xbox 360, NES, other)
- type of recompilation or port, and whether it is static recompilation, an HLE runtime, an emulator or a native port
- languages, runtime and libraries, renderer and audio backends
- code structure: where loader, runtime, hooks, patches, generated code, shaders and tests live
- build systems and the exact build commands
- test scripts and which of them are headless
- packaging tools and release artifact names
- supported platforms (Windows, Linux, other) and how they differ
- supported game builds and versions, and how they are detected
- local-only folders that must never be tracked or packaged (game data, saves, caches, logs, build output)

Treat anything not confirmed in the repository as unknown. Never copy a fact from another project.

## 2. Absolute Git rules (permanent, not suspended by a chat message)

Never run any Git, GitHub or equivalent operation that writes to the repository, index, history, a remote or a hosting service. This applies to scripts, wrappers, third-party tools, subagents, CLI, API and MCP tools.

Forbidden: `git add`, `commit`, `push`, `merge`, `rebase`, `cherry-pick`, `checkout`, `switch`, `reset`, `stash`, `tag`, `clean`, `rm`, `apply`; also `restore`, `revert`, `am`, `pull`, `fetch`, `mv`, `worktree`, `update-ref`. Forbidden: creating, editing, closing or merging Pull Requests; creating, editing or closing Issues; comments on PRs, Issues, Discussions or commits; reviews, approvals, requests for changes; releases and publishing artifacts; any remote change.

Allowed (read only): `git status`, `diff`, `show`, `log`, `ls-files`, `check-ignore`, `diff --check`, and `gh` read commands such as `gh pr view`.

Editing source files as part of the task is allowed. If the user asks for a forbidden Git operation, prepare the exact commands and the commit message as text for the user to run. Do not use `git -C`, `git -c`, `--git-dir`, `--work-tree`, `env git`, `command git` or a full path to git to get around this.

Commit messages, commit titles and bodies, `git commit` commands prepared for the user, squash suggestions, merge messages, templates and any other text destined for Git history never contain AI attribution. This is permanent, including when a detailed message is requested. Forbidden: `Co-Authored-By`, `Signed-off-by` or `Generated-by` for an assistant or model, `Assisted-by`, names of AI tools, assistants, models or companies (Claude, Claude Code, Opus, Sonnet, Haiku, Anthropic, ChatGPT, OpenAI, GPT, Gemini, Copilot), assistant e-mail addresses, AI signatures, credits, trailers, footers, or any reference to AI use in the implementation. Do not repeat AI trailers from earlier examples. Messages describe only the technical changes, in objective English following the project's convention, for example `feat: add Exit Game option to the menu`, `fix: prevent crash during renderer shutdown`, `refactor: simplify runtime initialization`.

## 3. Execution rules

Never start automatically: the game, launchers, graphical applications, test windows, anything that steals focus, anything that produces audio, interactive gameplay tests, graphics debuggers such as RenderDoc, any application that interferes with the user's desktop session. Never run a build script with a run or launch option, or a wrapper that launches the game. Only CLI commands and tests proven headless are allowed. No `Start-Process`, `start`, `explorer`, `Invoke-Item`.

Work autonomously on reading, investigation, editing and light validation: do not ask permission, and do not ask the user to run a simple command you can run safely. Prefer the native Read, Glob, Grep and Edit tools. Never use scripts, wrappers or interpreters (`node -e`, `python -c`, `pwsh -Command`, `bash -c`) to get around a block or a prompt, and never run a dangerous command just to avoid one. Do not make the user type environment variables, edit INI/JSON or run diagnostic scripts to test a feature; use direct tests and hotkeys.

Builds are off by default. Full, clean or rebuild builds, the project's test gate and long test suites, packaging, and toolchain or dependency rebuilds run only when the user explicitly asks. Local permission settings leave these to the default prompt; the prompt is not a request. Avoid background processes unless needed. Do not start several agents just because parallelism exists.

The user owns the real tests: gameplay, controls, video, audio, launcher. Finish with the exact manual test to run.

## 4. Default workflow

1. Understand the request. 2. Locate only the relevant files. 3. Investigate with the least context. 4. Implement bounded changes. 5. Run only static and light checks. 6. Give the exact manual test. 7. Wait for the result. 8. Fix what it shows. 9. Short diff review. 10. Prepare the commit only as text and commands.

No extensive validation after every small change. Do not touch unrelated code. Never store investigation history in comments. Keep the line endings the repository already uses; check them after editing.

## 5. Windows and Linux parity

When the project supports both, every existing Windows feature must be considered for Linux. Check where relevant: launcher, menus, settings, controls and hotkeys, cheats, saves and achievements, resolutions and ultrawide, rendering, audio, multiplayer, localization, logging, bug reports, packaging, runtime compatibility.

Do not claim parity without evidence. Every code review checks functional equivalence, not only that it compiles; a new Windows feature considers its Linux equivalent and the reverse. A platform the project does not support is not applicable. If one platform cannot be implemented or verified, state it as a pending item. For UI work, check 100%, 150% and 225% DPI when relevant. Use the `cross-platform-parity` skill.

## 6. Native safety

Pay extra attention to: ABI and calling conventions, hooks, RVAs, fingerprints, binary patches, memory and pointers, threads and concurrency, patch rollback, persistence, save data, compatibility across game builds, crash and memory corruption. Hard investigations produce evidence before implementation. No random trial and error. Use the `recomp-investigation` and `native-patch-review` skills.

## 7. Economical orchestration

The main agent is the orchestrator: understand, judge complexity and risk, pick the smallest set of files, decide whether to delegate, pick agents and models, avoid repeated work, consolidate evidence, control consumption, deliver the final report. Use the `orchestration-cost-control` skill when delegation is in question.

- Zero subagents for simple tasks. One when isolation of context or specialization gives a concrete benefit. Two only when the responsibilities are really independent.
- Sequential by default. Parallel only with an explicit reason. No delegation chains, no subagent recursion, no two implementers on the same files, no repeating one investigation on several models.
- Use the cheapest model that can finish the task correctly.

Project agents (`.claude/agents/`, `.opencode/agents/`):

| Role | Claude Code | OpenCode | Use |
|---|---|---|---|
| main / orchestrator | session model | `orchestrator` (primary), `opencode-go/deepseek-v4.1-flash` | plan, delegate, integrate, report |
| scout | `claude-haiku-5-5`, low (medium for harder bounded investigation) | `opencode-go/deepseek-v4.1-flash` | read-only search, logs, evidence |
| implementer | `claude-sonnet-5-5`, medium | `opencode-go/deepseek-v4-pro` | bounded edits from a defined plan |
| reviewer | `claude-sonnet-5-5`, medium (high only for a deep technical review) | `opencode-go/deepseek-v4-pro` | read-only diff review |
| native-specialist | `claude-opus-5-5`, medium | `opencode-go/kimi-k3.1-pro` | reverse engineering, ABI, unknown crashes |
| build-release | `claude-sonnet-5-5`, medium (high only for complex Release prep or investigation) | `opencode-go/deepseek-v4-pro` | build diagnosis, packaging, AppImage, artifacts, release hygiene |
| final-reviewer | `claude-opus-5-5`, medium (high only for a technical reason) | `opencode-go/kimi-k3.1-pro` | read-only final review: branch closure, release, critical reviews |

Two review levels: `reviewer` (Sonnet medium) for diffs, small fixes and local regressions; `final-reviewer` (Opus) only for the final review. Never use Opus for trivial reviews, never run `build-release` or `final-reviewer` on simple tasks, never repeat a full review after a small change.

Rules: Haiku low for searches, inventories, small logs; Haiku medium for bounded investigation and evidence gathering (never ABI, hard concurrency, architecture or hooks). Sonnet medium is the default for defined implementation, normal fixes, launcher/menus/settings, focused tests and simple reviews. Sonnet high only with a reason: complex or extensive risky change, deep review, delicate cross-platform or complex Release work; never just because the task is C, C++, Vulkan or recompilation. Opus medium directly for problems without a clear solution (unknown crash, reverse engineering, hard ABI and hooks, memory, concurrency, architecture, persistent problems, final review) instead of several unproductive Sonnet high attempts. Opus high only for exceptionally hard cases after solid investigation. Fable 5.2 only exceptionally (very large architectural refactor, complex migration, a problem Opus high could not solve), never automatically. Never use Opus to find files, run simple commands or summarize logs. High, xhigh or max effort needs a technical reason.

Effort before model: adjust reasoning effort before moving to a costlier model, but this is not a mandatory ladder. Before escalating, decide whether the failure was missing context, insufficient evidence, a wrong spec, an implementation error, a tool limit or real reasoning complexity; never rerun the same prompt on another model without new evidence.

Context economy: read only files relevant to the task, never the whole repository or all skills upfront; do not reread files or repeat finished investigations; use `.claude/project-context.md` only when relevant; keep reports and intermediate output short and objective while preserving essential evidence; no extra calls just to measure or reduce consumption. When a session gets very long, suggest compaction or a new session if it helps, without losing evidence of an investigation in progress.

In OpenCode prefer the economical models of the plan for investigation and bounded implementation. Do not mix Claude subscription use with the OpenCode plan, and do not assume they share credits. If a model or provider is unavailable, use the configured fallback of that tool. Do not configure model ids that were not verified (`opencode models`).

Subagents do not get the main agent's chat. Every agent file embeds the Git and execution prohibitions. Brief a subagent with goal, files, what is already ruled out and the expected short answer.

## 8. Mandatory report at the end of every task

Every final report must state:

AGENTS USED: total agents actually executed (the main agent counts), number of subagents (write "0 subagents" when none), name or role, model, effort when available, responsibility and result of each. Do not count agents that were only configured.

CONSUMPTION, only when the tool exposes it: input tokens, output tokens, cache read, cache write, total per agent when measurable, session total, estimated cost per model, total estimated cost, provider. Use real tool data. Never invent tokens, prices or costs. Write `N/D - not available` when there is no measurement. With only an aggregate cost, show the aggregate and do not split it between agents. Separate API-equivalent cost from actual billing; on a subscription do not treat API-equivalent cost as an extra expense. Do not add values from different plans as one charge. Do not include tokens of other sessions unless stated. Do not write scripts, resident processes or extra model calls just to compute cost.

REQUIRED SUMMARY:

- Classification: `PRECISA DE AJUSTE`, `PRONTO PARA TESTE` or `AGUARDANDO INFORMAÇÃO`
- What was done: short
- Agents: count and responsibilities
- Consumption: tokens and costs available, source, limits
- Validation: what was checked and what was not run
- Next step: manual test or required action

## 9. Comment policy

Keep source comments minimal. No project memory, implementation history, research notes, documentation dumps or tutorials in comments. Prefer clear names, small functions and readable code. A normal function needs zero comments or one short one. Comment only when code cannot show WHY a non-obvious constraint exists: ABI, mathematical constants, threading, game-specific invariants, patches and hooks, compatibility, safety. Do not comment obvious operations or document every field, RVA, offset, transition, test or step. Do not explain discovery or keep context for future AI sessions. Do not rewrite unrelated comments; fix an incorrect one with the shortest accurate wording. `DEBUG_SAULO` comments and diagnostics are temporary and removable. In the final review remove verbose, redundant, historical and tutorial comments.

## 10. Skills (loaded on demand, in `.claude/skills/`)

`recomp-investigation`, `recomp-implementation`, `native-patch-review`, `cross-platform-parity`, `lightweight-validation`, `release-audit`, `orchestration-cost-control`.

## 11. Build, logs, tests, Worker, release (universal; applies when the project has the tool)

- **Incremental build.** A project with `build.ps1` builds incrementally by default: keep valid objects, caches, stamps and fingerprints, no clean, no full rebuild, no needless codegen or rebuild of dependencies and graphics plugins, no change of the selected configuration. Run it only on an explicit request, never with `-Run`. Fix an unnecessary clean or rebuild with a targeted change; do not replace a working build system or add a second `build.ps1`.
- **Build logs.** Each build run writes exactly one new consolidated log `<project>_NNN.log` (normalized project name, at least three digits, increasing, never reused or overwritten, reserved atomically so concurrent builds never share one): stdout and stderr, configuration, incremental or complete, start and end, result, original exit code, kept even when the build fails early. Use the project's log folder (it must differ from runtime game logs when those share the pattern), ignored by Git. Never delete old logs, never ship them. Report the path.
- **`test.ps1`.** Every new feature (patch, fingerprint, supported build, setting, launcher feature, cheat, hotkey, control, render option, audio, multiplayer or online feature, language, save or persistence, platform feature, packaging option) and every fixed regression gets a check in the project's `test.ps1` when it can be verified automatically. Fast, static and headless; no artificial tests, no heavy harness, no extra full builds. Say which tests were added and which cannot be automated (GPU, UI, audio, gameplay) and give the manual test instead. Run only fast headless tests; never the gate unless asked.
- **Cloudflare Worker.** When the project manages a Worker (wrangler config), `tools/worker.ps1` (or the existing equivalent) deploys it from the repository root: it finds the root through `$PSScriptRoot`, validates files and Wrangler, uses the official flow and the user's existing authentication, stores no tokens, installs nothing, never logs in, never touches secrets or bindings, restores the working directory. Create or adjust it locally; never run it, never run `wrangler` or any deploy. The user deploys. No Worker, no script.
- **Final review.** Before closing a branch or preparing a release: `final-reviewer` covers code, native, UI, cleanup, Windows/Linux functional parity (not just compilation, including packaged artifacts), `test.ps1`, incremental build with numbered logs, and `worker.ps1` compatibility. Findings only, with evidence and severity; the implementer fixes.
- **Release.** Use the project's official scripts and version source; Release configuration in the final package; names follow the project, else `ProjectName-v<version>-windows-x64.zip` and `ProjectName-v<version>-x86_64.AppImage`. The package has no game data, saves, logs (including build logs), dumps, credentials, `DEBUG_SAULO`, absolute developer paths or stale binaries; recompute hashes after any change. AppImage and VirusTotal rules are in the `release-audit` skill. Never upload to VirusTotal or any external service, even if the user asks; the user uploads manually. Without a real report write NOT VERIFIED; no evasion techniques.
- **Manual tests.** Never ask the user to set environment variables, run commands to enable a fix, edit INI or JSON, write launch scripts or rebuild several times to toggle fixes. Flow: implement, validate statically, user builds normally, opens the game normally, tests, sends the log. When a runtime toggle is unavoidable, use a temporary hotkey or an existing diagnostic menu (check key conflicts, no new panels) marked `DEBUG_SAULO`, removed before release.

## 12. Enforcement limits

Claude Code: `deny` rules in `.claude/settings.local.json` block Git and `gh` writes, deploy and publish commands (including `worker.ps1` and `wrangler`), launch commands and flags, graphics tools and launching MCP tools. `allow` rules cover only read-only forms (Git queries, search, listing, hashing, version and syntax checks, each also with the `rtk ` prefix the RTK hook adds), `defaultMode` is `acceptEdits` so normal edits in the repository do not prompt, and a few `ask` rules guard recursive deletes. There is no blanket `allow` and no `ask` for builds: a command that is neither allowed nor denied (builds, installs, tests, packaging, executables, interpreters) prompts by default, and that prompt is not an explicit user request to build. Precedence is deny, then ask, then allow, so a broad `ask` would cancel a narrow `allow`; keep `ask` rules narrow. Deny patterns are anchored at the start of each sub-command (Claude Code splits `&&`, `;` and pipes), so searching for the text `git push` is not blocked. OpenCode: `policies` in `.opencode/opencode.json` hard-deny the same categories and apply after agent rules and saved approvals, so no agent `allow` can lift them; shell asks by default with a short read-only allow-list, and the scout, reviewer, final-reviewer and native-specialist agents deny `edit`.

Limits, not absolute protection:
- Rules match command text. A path to git, a script that calls git or a launcher internally, an interpreter one-liner, or encoded commands can escape them. A game or launcher cannot be recognized by name in a universal config; it is covered only by the generic launch rules, the default prompt on executables, and the instructions above.
- `.claude/hooks/command-guard.js` (PreToolUse on Bash and PowerShell) parses each command with quotes, operators, wrappers (`env`, `rtk proxy`, `timeout`, `sudo`, `xargs`, `VAR=x`), git global options, full paths and nested `bash -c` / `pwsh -Command` / `-EncodedCommand`, and denies Git writes, `gh` writes, publish/deploy, `wrangler`, launch scripts and launch flags. It is a second layer over the static deny rules, fails open if Node is missing, and cannot see inside `python -c` or `node -e` strings (not allowed, so they use the default prompt). Editing the Claude settings, the hook or the OpenCode config asks first.
- `acceptEdits` approves edits and basic file commands inside the project; `rm` with options, `rmdir`, recursive or forced `Remove-Item` and edits of `.env`, key and `.git` files ask or are denied. A plain `rm file` inside the project is still auto-approved.
- Launcher and worker script names (`run.ps1`, `launch.*`, `worker.ps1`) are denied by command text in PowerShell and in the OpenCode policies; a search whose command line names them can be blocked, so use Grep or Read for those. The OpenCode `git`/`gh` policies are contains-style too and can block `grep "git push"`; use the search tools.
- The RTK hook (user-global) rewrites commands, and auto mode cannot review a call a hook changed, which prompts on safe commands. RTK's `hooks.exclude_commands` (user-global `config.toml`, backup beside it) lists the read-only commands RTK must leave untouched: git, gh, grep, rg, cat, head, tail, ls, find, wc, diff. Build and test tools are still compressed by RTK. This is user-level and affects every project.
- Permissions do not stop a shell command from writing files, so read-only agents rely on their instructions for that.
- Builds and packaging can only be gated by prompt, because the user must be able to request them.

The rules in this file stay binding even where a block is missing.
